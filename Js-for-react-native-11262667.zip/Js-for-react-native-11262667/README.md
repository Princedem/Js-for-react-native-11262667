# js-for-react-native-11262667

## Introduction
An Alternative Version of the UGCSD Website. 
## Setup

Follow these steps to clone repository:

* Fork this repository to your own GitHub account.
* Copy the URL of your forked repository.
* (Open your terminal and navigate to the directory where you want to clone the project.
* Run the command "git clone <URL>" where <URL> is the URL of your forked repository.
* Open the project folder in your code editor of choice.
* To view the website, open the index.html file in your browser or use a Live server extension.

## Author

Ayertey Prince Tetteh - 11262667
#[text](arrayManipulation.js)[text](userInfo.js)